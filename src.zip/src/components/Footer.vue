<template>
  <div id="Footer">
    <div id="Footer_line"></div>
    <div id="Footer_contain" ><p>关于我们 - 联系我们</p><p>Copyright ©2019</p></div>
  </div>
</template>
 
<script>

 
</script>
 
<style scoped>
#Footer{
	background-color: #2196F3;
    width: -webkit-fill-available;
    text-align:center
}
 #Footer_line{
 border-radius:35px;
 height: 2px;
 width: -webkit-fill-available;
 background-color: #1299FF;
 }
 #Footer_contain{
 //background-color: red;

 width: -webkit-fill-available;
 }
</style>