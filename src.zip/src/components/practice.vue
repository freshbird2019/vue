<template>
<div id="practice">
    <el-container>
        <el-header style="background-color:red;">
        </el-header>
        <el-main style="height:525px;background-color:green;">
        </el-main>
        <el-footer  style="padding:0;border:0;height:35px;background-color:blue;">
        </el-footer>

    </el-container>
</div>
</template>
 
<script>
export default{
    data(){
        return{

        };
    },
    methods:{
        
    }

}
</script>
 
<style  scoped>
.el-main{
    width: -webkit-fill-available;
}
</style>